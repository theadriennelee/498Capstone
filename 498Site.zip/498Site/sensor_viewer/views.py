from django.shortcuts import render
from django.urls import reverse_lazy
from django.contrib.auth.forms import UserCreationForm
from django.views.generic.edit import CreateView
from . import models, helper_functions, constants as const
from datetime import datetime
import numpy as np

# Create your views here.

def home(request):
    # Get a list of sensors; display name, last update, status, name
    models.update_sensor_status(const.MOCK_DATE)
    sensors = models.get_all_sensors()
    sensor_info = []
    anomaly_count = [0, 0, 0]

    # Extract the sensor information
    for sensor in sensors:
        sensor_data = models.get_sensor_data(sensor, const.MOCK_DATE, 7)
        sensor_anomalies = sensor_data["anomaly"].tolist()
        anomaly_count[0] += len(sensor_anomalies) - sum(sensor_anomalies)
        anomaly_count[1] +=  sum(sensor_anomalies)
        anomaly_count[2] += 7 * 24 * 6 - len(sensor_anomalies)

        sensor_info.append({
            "hide": False,
            "name": sensor.name,
            "value": models.get_latest_value(sensor=sensor),
            "display": sensor.display_name,
            "status_color": const.STATUS_ORB_COLOURS[str(sensor.status)],
            "status": const.STATUS[str(sensor.status)],
            "last_update": helper_functions.time_since(models.get_latest_timestamp(sensor=sensor), const.MOCK_DATE)
        })

    # Construct summary table
    summary_table = models.get_summary_statistics(const.MOCK_DATE, [1, 3, 7, 28])

    # Reformat the list
    sensor_grid = []
    for i in range(0, len(sensor_info), 4):
        sensor_row = sensor_info[i:i+4]
        # Fill in blanks
        while len(sensor_row) < 4:
            sensor_row.append(const.BLANK_SENSOR)
        sensor_grid.append(sensor_row)
    html_render_variables = {
        "sensor_grid": sensor_grid,
        "anomaly_count": anomaly_count,
        "summary_table": summary_table
    }
    return render(request, "sensor_viewer/home.html", context=html_render_variables)


def detailed_view(request):
    # Parse the request
    sensor_name = request.GET["sensor"]
    sensor = models.get_sensor(sensor_name)
    timeframe = int(request.GET["days"]) if "days" in request.GET else 7

    # Query the data
    sensor_data = models.get_sensor_data(sensor, const.MOCK_DATE, timeframe)
    anomalous_data = sensor_data[sensor_data["anomaly"]]
    regular_data = sensor_data[~sensor_data["anomaly"]]
    sensor_data["change"] = sensor_data.value.diff(periods=1).fillna(0)

    # Useful display variables
    sensor_anomalies = sensor_data["anomaly"].tolist()
    summary_table = {
        "Mean temperature": ["{} \N{DEGREE SIGN}C".format(round(np.mean(regular_data["value"]), 1)),
                             "{} \N{DEGREE SIGN}C".format(round(np.mean(anomalous_data["value"]), 1))],
        "Standard deviation": ["{} \N{DEGREE SIGN}C".format(round(np.std(regular_data["value"]), 2)),
                     "{} \N{DEGREE SIGN}C".format(round(np.std(anomalous_data["value"]), 2))],
        "Prediction MSE": [round(np.mean(regular_data["error"]), 2),
                           round(np.mean(anomalous_data["error"]), 2)],
    }

    # Render
    html_render_variables = {
        "sensor": sensor.display_name,
        "days": timeframe,
        "dates": [datetime.strftime(date, "%Y-%m-%d %H:%M:%S") for date in sensor_data["timestamp"].tolist()],
        "values": sensor_data["value"].tolist(),
        "error": sensor_data["error"].tolist(),
        "anomaly_bg": ["#ff7575" if anomaly else "transparent" for anomaly in sensor_anomalies],
        "anomaly_col": ["#6b0000" if anomaly else "transparent" for anomaly in sensor_anomalies],
        "anomaly_width": [1 if anomaly else 0 for anomaly in sensor_anomalies],
        "anomaly_count": [len(sensor_anomalies) - sum(sensor_anomalies), sum(sensor_anomalies), timeframe * 24 * 6 - len(sensor_anomalies)],
        "summary_table": summary_table
    }
    return render(request, "sensor_viewer/detailed.html", context=html_render_variables)


class SignUp(CreateView):
    form_class = UserCreationForm
    success_url = reverse_lazy("login")
    template_name = "registration/signup.html"
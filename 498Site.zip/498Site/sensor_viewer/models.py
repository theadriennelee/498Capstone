from django.db import models
from datetime import datetime, timedelta
import pandas as pd
from . import constants as const

# Create your models here.
class Sensor(models.Model):
    name = models.TextField()
    display_name = models.TextField()
    sensor_threshold = models.FloatField()
    status = models.IntegerField()


class SensorData(models.Model):
    sensor = models.ForeignKey(Sensor, on_delete=models.CASCADE)
    timestamp = models.DateTimeField()
    value = models.FloatField()
    error = models.FloatField()
    anomaly = models.BooleanField()

    class Meta:
        unique_together = (("sensor_id", "timestamp"))


def get_latest_timestamp(sensor=None, to_string=False):
    """
    Get the most recent timestamp in the DB
    :return:
    """
    try:
        if not sensor:
            recent = SensorData.objects.latest("timestamp")
        else:
            recent = SensorData.objects.filter(sensor=sensor).latest("timestamp")
    except:
        return None
    if to_string:
        return recent.timestamp.strftime("%m/%d/%y %H:%M:%S")
    return recent.timestamp


def get_latest_value(sensor=None):
    if sensor is None:
        return None
    try:
        recent = SensorData.objects.filter(sensor=sensor).latest("timestamp")
    except:
        return None
    return recent.value


def get_all_sensors():
    """
    Get all the sensors and their info
    """
    sensors = list(Sensor.objects.all())
    return sensors


def get_sensor(sensor_name):
    """
    Get the requested sensor object
    """
    return Sensor.objects.get(name=sensor_name)


def register_sensor(name, display, threshold):
    sensor = Sensor.objects.create(name=name, display_name=display, sensor_threshold=threshold, status=3)
    return sensor


def push_sensor_data(sensor, timestamp, value, error, anomaly):
    data = SensorData.objects.create(sensor=sensor, timestamp=timestamp, value=value, error=error, anomaly=anomaly)


def sensor_exists(name):
    try:
        sensor = Sensor.objects.get(name=name)
        return sensor
    except:
        return False


def update_sensor_status(current_time):
    # update the sensors according to time
    # last 10  timestamps was anomalous for at least 5 - red (3)
    # last timestamp was over 10 minutes late - gray (3)
    # last week of timestamps had >5% anomaly - yellow
    # otherwise green
    sensors = get_all_sensors()
    for sensor in sensors:
        data = get_sensor_data(sensor, current_time, const.SENSOR_STATUS_WINDOW)
        if data is None:
            sensor.status = 3
        elif data["timestamp"][len(data.index) - 1] < current_time - timedelta(minutes=30):
            sensor.status = 3
        elif sum(data.anomaly.tolist()[-10:]) > 5:
            sensor.status = 2
        elif sum(data.anomaly.tolist()) > len(data.index) * const.WARNING_PERCENT:
            sensor.status = 1
        else:
            sensor.status = 0
        sensor.save()


def get_sensor_data(sensor, current_time, days):
    # get the sensor data for a sensor within the time window
    try:
        data = SensorData.objects.filter(sensor=sensor, timestamp__gte=current_time - timedelta(days=days))
        df = pd.DataFrame(list(data.values()))
        return df
    except:
        return None


def get_summary_statistics(current_time, days):
    # get the statistics for the summary table: highest temp, highest error, worst sensor
    temperatures = []
    errors = []
    sensors = []
    for day in days:
        data = SensorData.objects.filter(timestamp__gte=current_time - timedelta(days=day))
        df = pd.DataFrame(list(data.values()))
        highest_temp_row = df.iloc[df["value"].idxmax()]
        temp_name = Sensor.objects.get(pk=highest_temp_row["sensor_id"]).display_name
        temperatures.append("{} \N{DEGREE SIGN}C ({})".format(round(highest_temp_row["value"], 1), temp_name))
        highest_error_row = df.iloc[df["error"].idxmax()]
        err_name = Sensor.objects.get(pk=highest_error_row["sensor_id"]).display_name
        errors.append("{} \N{DEGREE SIGN}C ({})".format(round(highest_error_row["error"], 1), err_name))
        anomalies = df[df["anomaly"]]
        if not anomalies.empty:
            anomalous_sensors = anomalies.groupby(["sensor_id"]).size()
            worst_sensor = anomalous_sensors.idxmax()
            malfunctions = anomalous_sensors[worst_sensor]
            total = df.groupby(["sensor_id"]).size()[worst_sensor]
            percent = malfunctions / total * 100
            sensor_name = Sensor.objects.get(pk=worst_sensor).display_name
            sensors.append("{} ({}% anomalous)".format(sensor_name, round(percent, 1)))
        else:
            sensors.append("No anomalies detected!")
    return {
        "Highest temperatures": temperatures,
        "Highest errors": errors,
        "Worst sensor": sensors
    }

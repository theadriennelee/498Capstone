from datetime import datetime
from django.utils import timezone
import pytz

SENSOR_STATUS_WINDOW = 7
WARNING_PERCENT = 0.02
STATUS_ORB_COLOURS = {
    "0": "#7df07d",
    "1": "#fff78a",
    "2": "#f05b5b",
    "3": "#a3a3a3"
}
STATUS = {
    "0": "Working",
    "1": "Recent malfunction",
    "2": "Active malfunction",
    "3": "Missing data"
}
MOCK_DATE = datetime(2016, 4, 16, 5, 21, 0, 0, pytz.UTC)
BLANK_SENSOR = {
    "hide": True,
    "name": "",
    "value": "",
    "display": "",
    "status": "",
    "last_update": ""
}
from datetime import datetime

def time_since(datetime, current_time):
    seconds = (current_time - datetime).total_seconds()
    if seconds >= 86400:
        return "{} days".format(int(seconds / 86400))
    if seconds >= 3600:
        return "{} hours".format(int(seconds / 3600))
    if seconds >= 60:
        return "{} minutes".format(int(seconds / 60))
    return "{} seconds".format(int(seconds))